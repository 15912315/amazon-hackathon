# CareCircle AI — Hackathon Prototype

CareCircle AI is a responsive front-end prototype for organizing family caregiving. It includes a dashboard, editable care checklist, a scripted demo assistant, and local care notes.

## Features
- Responsive dashboard with task progress and remaining-task count.
- Add tasks and mark them complete.
- Care assistant demo with rule-based sample responses.
- Save and clear care notes.
- Browser-local persistence using `localStorage`.
- Accessible form labels and mobile layout.

## Run locally
No build tools or API keys are required.

1. Unzip this project.
2. Open `index.html` in a modern browser.

For a local web server (optional), run:
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000`.

## Important scope and limitations
This is a hackathon prototype, not a production healthcare product. The assistant responses are scripted examples; no live AI model, AWS service, Alexa+ integration, Ring/BeeRing integration, authentication, or cloud database is connected in this code. Tasks and notes are stored only in the current browser using local storage. Do not enter real sensitive health information. The app does not diagnose conditions or replace professional medical advice.

## Suggested next steps
- Connect a real AI service with appropriate safeguards and disclose that integration clearly.
- Add secure authentication and a backend database before handling personal data.
- Add tests, error handling, privacy controls, and deployment configuration.
- Implement and test any Amazon/AWS integration required by the selected hackathon track before claiming track eligibility.

## Contents
- `index.html` — app structure
- `styles.css` — visual design and responsive layout
- `app.js` — interactions, local storage, and demo assistant
