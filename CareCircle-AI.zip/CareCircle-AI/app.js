const defaultTasks = [
  { id: 1, name: "Morning check-in", time: "Morning", done: true },
  { id: 2, name: "Prepare a balanced meal", time: "Afternoon", done: true },
  { id: 3, name: "Gentle activity or walk", time: "Afternoon", done: false },
  { id: 4, name: "Family check-in", time: "Evening", done: false }
];
const load = (key, fallback) => { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; } };
let tasks = load("carecircle_tasks", defaultTasks);
let notes = load("carecircle_notes", []);
const saveTasks = () => localStorage.setItem("carecircle_tasks", JSON.stringify(tasks));
const saveNotes = () => localStorage.setItem("carecircle_notes", JSON.stringify(notes));
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fmtDate = () => new Date().toLocaleDateString(undefined,{weekday:"short",month:"short",day:"numeric"});
document.getElementById("todayDate").textContent = fmtDate();
document.getElementById("careDate").textContent = fmtDate();

function renderTasks() {
  const html = tasks.map(t => `<div class="task-row ${t.done ? "done" : ""}"><input class="task-check" type="checkbox" data-task="${t.id}" ${t.done ? "checked" : ""} aria-label="Complete ${esc(t.name)}"><div style="flex:1"><span class="task-name">${esc(t.name)}</span><span class="task-meta">${esc(t.time)} · ${t.done ? "Completed" : "Pending"}</span></div></div>`).join("");
  document.getElementById("dashboardTasks").innerHTML = html || '<div class="empty-state">No tasks yet. Add one in your care plan.</div>';
  document.getElementById("careTasks").innerHTML = html || '<div class="empty-state">No tasks yet. Add one to start your plan.</div>';
  const done = tasks.filter(t => t.done).length;
  document.getElementById("completedCount").innerHTML = `${done} <small>/ ${tasks.length}</small>`;
  document.getElementById("progressBar").style.width = (tasks.length ? done/tasks.length*100 : 0) + "%";
  document.getElementById("reminderCount").textContent = tasks.filter(t=>!t.done).length;
}
function renderNotes() {
  document.getElementById("notesList").innerHTML = notes.length ? notes.slice().reverse().map(n=>`<div class="note-card"><strong>${esc(n.title)}</strong><p>${esc(n.body)}</p><small>${esc(n.date)}</small></div>`).join("") : '<div class="empty-state">No notes saved yet. Add your first update.</div>';
}
function go(page) {
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===page));
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  const titles={dashboard:"Good morning, Rahul ☀",assistant:"AI Assistant",care:"Care plan",notes:"Care notes"};
  document.getElementById("pageTitle").textContent=titles[page]||"CareCircle AI";
  window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));
document.querySelectorAll("[data-goto]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.goto)));
document.addEventListener("change",e=>{if(e.target.matches("[data-task]")){const t=tasks.find(t=>t.id===Number(e.target.dataset.task));if(t){t.done=e.target.checked;saveTasks();renderTasks();}}});
const dialog=document.getElementById("taskDialog");
document.getElementById("addTaskBtn").addEventListener("click",()=>dialog.showModal());
document.getElementById("closeDialog").addEventListener("click",()=>dialog.close());
document.getElementById("cancelDialog").addEventListener("click",()=>dialog.close());
document.getElementById("taskForm").addEventListener("submit",e=>{e.preventDefault();const name=document.getElementById("taskName").value.trim();if(!name)return;tasks.push({id:Date.now(),name,time:document.getElementById("taskTime").value,done:false});saveTasks();renderTasks();e.target.reset();dialog.close();});
document.getElementById("noteForm").addEventListener("submit",e=>{e.preventDefault();notes.push({title:document.getElementById("noteTitle").value.trim(),body:document.getElementById("noteBody").value.trim(),date:new Date().toLocaleString()});saveNotes();renderNotes();e.target.reset();});
document.getElementById("clearNotes").addEventListener("click",()=>{if(confirm("Clear all saved notes from this browser?")){notes=[];saveNotes();renderNotes();}});
const responses=[
  {keys:["morning","routine","plan"],text:"A calm routine can start with a friendly check-in, a little time to get ready, breakfast, and reviewing the day's appointments. Keep the plan flexible and ask the person receiving care what feels comfortable for them."},
  {keys:["doctor","visit","appointment","ask"],text:"You could prepare questions such as:\n• What changes should we watch for?\n• Are there daily activities or routines we should adjust?\n• What should we do if symptoms change?\n• When should we schedule follow-up?\nBring an up-to-date list of medicines and concerns, and confirm medical advice directly with the clinician."},
  {keys:["caregiver","family","support","stress","tired"],text:"Caregiving is easier when responsibilities are shared. Try a short family check-in, divide tasks clearly, plan breaks, and ask what support each person needs. If you're feeling overwhelmed, consider speaking with a trusted person or a local caregiver support service."},
  {keys:["reminder","task","organize","schedule"],text:"A practical way to organize care is to group tasks by morning, afternoon, and evening. Keep reminders specific, assign a person when useful, and review the checklist together. Add tasks in the Care plan section to try this demo."},
  {keys:["food","meal","eat","water","hydration"],text:"For general meal planning, consider the person's preferences, usual routine, and any dietary guidance they have received. Keep water accessible if appropriate, and ask a healthcare professional about individual nutrition or fluid restrictions."}
];
function getReply(input){const s=input.toLowerCase();const found=responses.find(r=>r.keys.some(k=>s.includes(k)));return found?found.text:"I can help with general caregiving organization, daily routine ideas, and questions to prepare for a healthcare professional. Try asking about a morning routine, a doctor visit, caregiver support, or organizing reminders. This prototype does not diagnose conditions or provide personalized medical advice.";}
function addMessage(text,who){const d=document.createElement("div");d.className="message "+who;d.textContent=text;document.getElementById("chatMessages").appendChild(d);d.scrollIntoView({block:"nearest",behavior:"smooth"});}
document.getElementById("chatForm").addEventListener("submit",e=>{e.preventDefault();const input=document.getElementById("chatText");const value=input.value.trim();if(!value)return;document.querySelector(".suggestions")?.remove();addMessage(value,"user");input.value="";setTimeout(()=>addMessage(getReply(value),"bot"),180);});
document.querySelectorAll(".suggestions button").forEach(b=>b.addEventListener("click",()=>{document.getElementById("chatText").value=b.textContent;document.getElementById("chatForm").requestSubmit();}));
document.getElementById("clearChat").addEventListener("click",()=>{document.getElementById("chatMessages").innerHTML='<div class="message bot">Hi Rahul! I can help with general caregiving tips, routine ideas, and questions for a healthcare professional. What would be helpful today?</div>';});
renderTasks();renderNotes();